export interface TableItem {
    id: number;
    category: string;
    product_name: string;
    product_desc: string;
    color: string;
    currency: string;
    price: number;
    quantity: number;
  }
  
  export interface Filter {
    column: string;
    operator: 'equals' | 'contains'; // Add other operators as needed
    value: string;
  }
  