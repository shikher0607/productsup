import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  @Output() filterApplied = new EventEmitter<any>();
  
  selectedColumn = 'id';
  selectedOperator = 'equals';
  filterValue = '';

  public applyFilter(): void {
    const filter = {
      column: this.selectedColumn,
      operator: this.selectedOperator,
      value: this.filterValue
    };
    this.filterApplied.emit(filter);
  }

  public clearFilterValue(): void {
    this.filterValue = '';
  }

  public resetFilters(): void {
    this.selectedColumn = 'id';
    this.selectedOperator = 'equals';
    this.filterValue = '';
    this.applyFilter();
  }
}
