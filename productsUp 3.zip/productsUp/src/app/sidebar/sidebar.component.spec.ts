import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SidebarComponent } from './sidebar.component';

describe('SidebarComponent', () => {
  let component: SidebarComponent;
  let fixture: ComponentFixture<SidebarComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SidebarComponent],
    });
    fixture = TestBed.createComponent(SidebarComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize selectedColumn to "id"', () => {
    expect(component.selectedColumn).toBe('id');
  });

  it('should initialize selectedOperator to "equals"', () => {
    expect(component.selectedOperator).toBe('equals');
  });

  it('should initialize filterValue to an empty string', () => {
    expect(component.filterValue).toBe('');
  });

  it('applyFilter should emit filter object', () => {
    let emittedFilter: any = null;
    component.filterApplied.subscribe((filter) => {
      emittedFilter = filter;
    });

    component.selectedColumn = 'category';
    component.selectedOperator = 'contains';
    component.filterValue = 'test';

    component.applyFilter();

    expect(emittedFilter).toEqual({
      column: 'category',
      operator: 'contains',
      value: 'test',
    });
  });

  it('clearFilterValue should reset filterValue to an empty string', () => {
    component.filterValue = 'test';
    component.clearFilterValue();
    expect(component.filterValue).toBe('');
  });

  it('resetFilters should reset selectedColumn, selectedOperator, and filterValue, and call applyFilter', () => {
    const applyFilterSpy = spyOn(component, 'applyFilter');
    component.selectedColumn = 'category';
    component.selectedOperator = 'contains';
    component.filterValue = 'test';

    component.resetFilters();

    expect(component.selectedColumn).toBe('id');
    expect(component.selectedOperator).toBe('equals');
    expect(component.filterValue).toBe('');
    expect(applyFilterSpy).toHaveBeenCalled();
  });
});
