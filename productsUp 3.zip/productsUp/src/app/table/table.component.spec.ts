import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TableComponent } from './table.component';
import { TableService } from './table.service';
import { of } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SidebarComponent } from '../sidebar/sidebar.component';

describe('TableComponent', () => {
  let component: TableComponent;
  let fixture: ComponentFixture<TableComponent>;
  let tableService: TableService;
  
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TableComponent, SidebarComponent],
      providers: [TableService],
      imports: [HttpClientModule, HttpClientTestingModule], // Add these imports
    });

    fixture = TestBed.createComponent(TableComponent);
    component = fixture.componentInstance;
    tableService = TestBed.inject(TableService);
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize component properties', () => {
    expect(component.tabledata).toEqual([]);
    expect(component.originalTabledata).toEqual([]);
    expect(component.isAscending).toBeTruthy();
    expect(component.sortKey).toBe('');
    expect(component.itemsPerPage).toBe(50);
    expect(component.currentPage).toBe(1);
  });

  it('should call getTableData on ngOnInit', () => {
    spyOn(tableService, 'getTableData').and.returnValue(of([]));
    component.ngOnInit();
    expect(tableService.getTableData).toHaveBeenCalled();
  });

  it('should not navigate beyond the last page', () => {
    component.currentPage = 3; // Assuming there are 3 pages in total
    component.nextPage();

    expect(component.currentPage).toBe(3);
  });

  it('should navigate to the previous page', () => {
    component.currentPage = 2;
    component.previousPage();

    expect(component.currentPage).toBe(1);
  });

  it('should apply a filter correctly', () => {
    component.originalTabledata = [
      { id: 3, category: 'Category B', product_name: 'Product C', product_desc: 'product_desc', color: 'white', currency: 'USD', price: 10, quantity: 10 }
    ]
    component.applyFilter({ column: 'category', operator: 'equals', value: 'Category B' });

    expect(component.tabledata.length).toBe(1);
    expect(component.tabledata[0].category).toBe('Category B');
  });
});
