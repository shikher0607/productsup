import { TestBed, inject } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TableService } from './table.service';

describe('TableService', () => {
  let service: TableService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [TableService],
    });

    // Inject the service and test controller
    service = TestBed.inject(TableService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should retrieve table data from the API via GET', () => {
    const expectedData = [{ id: 1, name: 'Item 1' }, { id: 2, name: 'Item 2' }];
    
    // Make an HTTP GET request
    service.getTableData().subscribe(data => {
      expect(data).toEqual(expectedData);
    });

    // Expect a single request to a specific URL
    const req = httpTestingController.expectOne('assets/table_data.json');
    expect(req.request.method).toBe('GET');

    // Respond with the mock data
    req.flush(expectedData);

    // Verify that there are no outstanding requests
    httpTestingController.verify();
  });
});

