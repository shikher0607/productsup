import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs';
import { Filter, TableItem } from '../types/table.types';
import { TableService } from './table.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {
  public tabledata: TableItem[] = [];
  public originalTabledata: TableItem[] = [];
  public isAscending = true;
  public sortKey = '';
  public itemsPerPage: number = 50;
  public currentPage: number = 1;

  constructor(protected tableService: TableService) {}

  public ngOnInit(): void {
    this.getTableData();
  }

  public sort(key: string): void {
    this.isAscending = !this.isAscending;
    this.sortKey = key;
    this.tabledata.sort((a: any, b: any) => {
      const modifier = this.isAscending ? 1 : -1;
      return a[key] > b[key] ? modifier : -modifier;
    });
  }

  public get totalPages(): number {
    return Math.ceil(this.tabledata.length / this.itemsPerPage);
  }

  public get paginatedData(): TableItem[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    return this.tabledata.slice(startIndex, endIndex);
  }

  public nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  public previousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  public applyFilter(filter: Filter): void {
    if (!filter || !filter.column || !filter.value) {
      // Invalid filter, do nothing
      this.tabledata = this.originalTabledata
      return;
    }

    const filterValue = filter.value.toLowerCase();
    this.tabledata = this.originalTabledata.filter((item: any) => {
      const columnValue = item[filter.column];

      if (columnValue) {
        const columnValueLower = columnValue.toString().toLowerCase();
        if (filter.operator === 'equals') {
          return columnValueLower === filterValue;
        } else {
          if (columnValueLower.includes(filterValue)) {
            return true;
          }
        }
      }
      return false;
    });

    this.currentPage = 1;
  }

  private getTableData(): void {
    this.tableService.getTableData().pipe(
      map((data) => Object.keys(data).map((key) => data[key] as TableItem))
    ).subscribe(data => {
      this.tabledata = data;
      this.originalTabledata = data;
    });
  }
}
